
from django.shortcuts import render, redirect
from matching.db import conn

def create_candidate(request):
    if request.method == "POST":
        name = request.POST.get("name")
        skill = request.POST.get("skill")

        query = '''
        MERGE (c:Candidato {name: $name})
        MERGE (s:Skill {name: $skill})
        MERGE (c)-[:TIENE_SKILL]->(s)
        '''
        conn.query(query, {"name": name, "skill": skill})

        return redirect("jobs")

    return render(request, "create_candidate.html")
