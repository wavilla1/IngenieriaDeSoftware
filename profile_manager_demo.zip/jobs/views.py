
from django.shortcuts import render
from matching.db import conn

def job_list(request):
    query = '''
    MATCH (v:Vacante)
    RETURN v.name as name
    '''
    jobs = conn.query(query)
    return render(request, "job_list.html", {"jobs": jobs})
