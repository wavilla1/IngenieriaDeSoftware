
from django.shortcuts import render
from matching.db import conn

def recommendations(request, name):
    query = '''
    MATCH (c:Candidato {name: $name})-[:TIENE_SKILL]->(s:Skill)
    MATCH (s)<-[:REQUIERE]-(v:Vacante)
    RETURN v.name as vacante, count(s) as score
    ORDER BY score DESC
    '''
    recs = conn.query(query, {"name": name})
    return render(request, "recommendations.html", {"recs": recs})
